// Cloud agency - Random Joke Generator
// Uses the JokeAPI: https://v2.jokeapi.dev/

const axios = require('axios');

async function getRandomJoke() {
  try {
    const response = await axios.get('https://v2.jokeapi.dev/joke/Any?safe-mode');
    const jokeData = response.data;

    if (jokeData.type === "single") {
      return jokeData.joke;
    }
    if (jokeData.type === "twopart") {
      return `${jokeData.setup}\n${jokeData.delivery}`;
    }
    return "Couldn't fetch a joke right now. Try again!";
  } catch (error) {
    return "Failed to fetch a joke. Please check your connection.";
  }
}

module.exports = {
  getRandomJoke
};