// Cloud agency WhatsApp Bot by Kalstanley Basanta
const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, makeInMemoryStore, Browsers } = require('@whiskeysockets/baileys');
const axios = require('axios');
const fs = require('fs');
const ytdl = require('ytdl-core');
const mime = require('mime-types');
const { getRandomJoke } = require('./joke-generator');

const BOT_NAME = 'Cloud agency';
const OWNER = 'Kalstanley Basanta';

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: true,
    browser: Browsers.macOS(BOT_NAME),
    markOnlineOnConnect: true
  });

  setInterval(() => {
    sock.sendPresenceUpdate('available');
  }, 60 * 1000);

  const store = makeInMemoryStore({});
  store.bind(sock.ev);

  // Set bot profile image
  try {
    const imageBuffer = fs.readFileSync('./bot-profile.jpg');
    await sock.updateProfilePicture(sock.user.id, imageBuffer);
  } catch (e) {
    console.log('Bot profile image not set:', e.message);
  }

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (let msg of messages) {
      if (!msg.message) continue;
      const m = msg.message;
      const sender = msg.key.remoteJid;
      const text = m.conversation || m.extendedTextMessage?.text || '';

      // Help/commands
      if (/^!help$/i.test(text)) {
        await sock.sendMessage(sender, { text: 
          `*Cloud agency* Bot\nOwned by ${OWNER}\n\nCommands:\n!status - View all statuses\n!download <url> - Download any media\n!everonline - Keep bot online\n!joke - Get a random joke\n!help - Show commands`
        });
      }

      // Auto Status Viewing
      if (/^!status$/i.test(text)) {
        const statuses = store.statusMessages;
        if (statuses && Object.keys(statuses).length) {
          for (const jid in statuses) {
            for (const status of statuses[jid]) {
              if (status.message.imageMessage) {
                await sock.sendMessage(sender, { image: status.message.imageMessage });
              } else if (status.message.videoMessage) {
                await sock.sendMessage(sender, { video: status.message.videoMessage });
              } else if (status.message.textMessage) {
                await sock.sendMessage(sender, { text: status.message.textMessage.text });
              }
            }
          }
        } else {
          await sock.sendMessage(sender, { text: "No status updates found." });
        }
      }

      // Downloader: !download <url>
      if (/^!download\s+(https?:\/\/\S+)/i.test(text)) {
        const url = text.match(/(https?:\/\/\S+)/)[1];
        try {
          if (ytdl.validateURL(url)) {
            const info = await ytdl.getInfo(url);
            const format = ytdl.chooseFormat(info.formats, { quality: 'highest' });
            const filePath = `downloads/${Date.now()}.mp4`;
            ytdl(url, { format }).pipe(fs.createWriteStream(filePath)).on('finish', async () => {
              await sock.sendMessage(sender, { video: { url: filePath }, caption: "Downloaded from YouTube." });
              fs.unlinkSync(filePath);
            });
          } else {
            const response = await axios.get(url, { responseType: 'arraybuffer' });
            const ext = mime.extension(response.headers['content-type'] || '') || 'bin';
            const filePath = `downloads/${Date.now()}.${ext}`;
            fs.writeFileSync(filePath, response.data);
            await sock.sendMessage(sender, { document: { url: filePath }, mimetype: response.headers['content-type'] || 'application/octet-stream', fileName: `Download.${ext}` });
            fs.unlinkSync(filePath);
          }
        } catch (e) {
          await sock.sendMessage(sender, { text: "Download failed: " + e.message });
        }
      }

      // Ever online
      if (/^!everonline$/i.test(text)) {
        await sock.sendMessage(sender, { text: "Bot will remain online. If you notice it's offline, restart on katabump panels or bot hosting net." });
      }

      // Random Joke command
      if (/^!joke$/i.test(text)) {
        const joke = await getRandomJoke();
        await sock.sendMessage(sender, { text: joke });
      }
    }
  });

  sock.ev.on('creds.update', saveCreds);

  console.log(`${BOT_NAME} started. Owner: ${OWNER}`);
}

startBot();